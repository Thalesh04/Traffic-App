# ─────────────────────────────────────────────────────
# app.py — entry point, run this file with streamlit
# Sets up page config, sidebar navigation, and routing
# ─────────────────────────────────────────────────────

import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from frontend import home, saved_routes
from backend.database import create_tables

# Must be first Streamlit command in the file
st.set_page_config(
    page_title = "Traffic Route App",
    page_icon  = "🚦",
    layout     = "wide"   # uses full browser width
)

# Create database tables on startup
# IF NOT EXISTS means safe to call every time app starts
create_tables()

# ─────────────────────────────────────
# SESSION STATE DEFAULTS
# Set default values if not already set
# These persist across page reruns
# ─────────────────────────────────────
if "search_done" not in st.session_state:
    st.session_state["search_done"] = False

if "user_id" not in st.session_state:
    st.session_state["user_id"] = 1   # default user, no login needed

# ─────────────────────────────────────
# SIDEBAR
# st.sidebar.anything puts it in left panel
# ─────────────────────────────────────
st.sidebar.title("🚦 Traffic Route App")
st.sidebar.divider()

# Radio buttons for navigation
# Returns the selected option as a string
page = st.sidebar.radio(
    "Navigate",
    ["🏠 Home", "⭐ Saved Routes"]
)

st.sidebar.divider()
st.sidebar.caption("Built with Streamlit + geopy")

# ─────────────────────────────────────
# PAGE ROUTING
# Show page based on sidebar selection
# ─────────────────────────────────────
if page == "🏠 Home":
    home.show()
elif page == "⭐ Saved Routes":
    saved_routes.show()