# ─────────────────────────────────────────────────────
# saved_routes.py — shows saved and frequent routes
# Two tabs: frequent routes and full search history
# ─────────────────────────────────────────────────────

import streamlit as st
import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.database import get_route_history, get_frequent_routes


def show():
    st.title("⭐ Saved & Frequent Routes")

    user_id = st.session_state.get("user_id", 1)

    # st.tabs creates clickable tabs
    # Everything inside "with tab1:" goes in the first tab
    tab1, tab2 = st.tabs(["⭐ Frequent Routes", "📋 Route History"])

    # ─────────────────────────────────────
    # TAB 1 — FREQUENT ROUTES
    # ─────────────────────────────────────
    with tab1:
        st.subheader("Your Most Used Routes")
        frequent = get_frequent_routes(user_id)

        if not frequent:
            st.info("No frequent routes yet. Start searching!")
        else:
            df = pd.DataFrame(frequent)
            # Rename columns for display
            df.columns = ["Origin", "Destination", "Times Used"]
            df.index   = df.index + 1   # start index from 1 not 0
            st.dataframe(df, use_container_width=True)

            # Highlight the top route
            # frequent[0] = first item = most used (sorted DESC)
            top = frequent[0]
            st.success(
                f"🏆 Most frequent: **{top['origin']}** → "
                f"**{top['destination']}** ({top['trip_count']}x)"
            )

    # ─────────────────────────────────────
    # TAB 2 — FULL HISTORY
    # ─────────────────────────────────────
    with tab2:
        st.subheader("Your Search History")
        history = get_route_history(user_id)

        if not history:
            st.info("No history yet.")
        else:
            df = pd.DataFrame(history)

            # Filter box — searches both origin and destination columns
            search = st.text_input("🔎 Filter", placeholder="Type to filter...")
            if search:
                # str.contains checks if search text appears in column
                # case=False = case insensitive
                # na=False = treat missing values as False not error
                # | = OR — match either column
                mask = (
                    df["origin"].str.contains(search, case=False, na=False) |
                    df["destination"].str.contains(search, case=False, na=False)
                )
                df = df[mask]   # filter to only matching rows

            st.dataframe(df, use_container_width=True)

            # Stats row
            st.divider()
            col1, col2, col3 = st.columns(3)

            all_history = get_route_history(user_id)
            all_frequent = get_frequent_routes(user_id)

            with col1:
                st.metric("Total Searches", len(all_history))
            with col2:
                st.metric("Unique Routes",  len(all_frequent))
            with col3:
                top_count = all_frequent[0]["trip_count"] if all_frequent else 0
                st.metric("Most Used Route", f"{top_count}x")