import streamlit as st
import pandas as pd
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.database import get_route_history, get_frequent_routes

# ─────────────────────────────────────────
# MAIN PAGE
# ─────────────────────────────────────────
def show():
    st.title("⭐ Saved & Frequent Routes")

    user_id = st.session_state.get("user_id", 1)

    # ─────────────────────────────────────
    # TABS
    # ─────────────────────────────────────
    tab1, tab2 = st.tabs(["⭐ Frequent Routes", "📋 Route History"])

    # ─────────────────────────────────────
    # TAB 1 - FREQUENT ROUTES
    # ─────────────────────────────────────
    with tab1:
        st.subheader("Your Most Used Routes")
        st.write("These are routes you search the most.")

        frequent = get_frequent_routes(user_id)

        if not frequent:
            st.info("No frequent routes yet. Start searching to build your history!")

        else:
            # Show as styled dataframe
            df = pd.DataFrame(frequent)
            df.columns = ["Origin", "Destination", "Times Used"]
            df.index   = df.index + 1   # start index from 1 not 0

            st.dataframe(df, use_container_width=True)

            # Most used route highlight
            top_route = frequent[0]   # already sorted by trip_count DESC
            st.success(
                f"🏆 Your most frequent route is "
                f"**{top_route['origin']}** → **{top_route['destination']}** "
                f"({top_route['trip_count']} times)"
            )

            st.divider()

            # Quick search button for each frequent route
            st.subheader("🔁 Quick Search")
            st.write("Click any route below to search it again instantly.")

            for route in frequent:
                col1, col2, col3 = st.columns([3, 3, 1])

                with col1:
                    st.write(f"📍 {route['origin']}")
                with col2:
                    st.write(f"🏁 {route['destination']}")
                with col3:
                    if st.button("Go", key=f"freq_{route['origin']}_{route['destination']}"):
                        # Store in session and redirect to home
                        st.session_state["quick_origin"]      = route["origin"]
                        st.session_state["quick_destination"] = route["destination"]
                        st.session_state["quick_search"]      = True
                        st.switch_page("app.py")

    # ─────────────────────────────────────
    # TAB 2 - ROUTE HISTORY
    # ─────────────────────────────────────
    with tab2:
        st.subheader("Your Search History")
        st.write("Every route you have searched, newest first.")

        history = get_route_history(user_id)

        if not history:
            st.info("No routes searched yet. Go to Home to search a route!")

        else:
            df = pd.DataFrame(history)
            df.columns = ["Origin", "Destination", "Distance", "Duration", "Searched At"]
            df.index   = df.index + 1

            # Search/filter box
            search = st.text_input("🔎 Filter history", placeholder="Type to filter...")
            if search:
                mask = (
                    df["Origin"].str.contains(search, case=False) |
                    df["Destination"].str.contains(search, case=False)
                )
                df = df[mask]

            st.dataframe(df, use_container_width=True)

            # Stats
            st.divider()
            st.subheader("📊 Your Stats")

            col1, col2, col3 = st.columns(3)

            with col1:
                st.metric("Total Searches", len(history))
            with col2:
                unique = len(set(
                    (r["origin"], r["destination"]) for r in history
                ))
                st.metric("Unique Routes", unique)
            with col3:
                frequent = get_frequent_routes(user_id)
                top = frequent[0]["trip_count"] if frequent else 0
                st.metric("Most Used Route", f"{top}x")