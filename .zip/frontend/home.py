import streamlit as st
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.maps import MapHandler
from backend.database import save_route, get_route_history
from frontend.map_view import render_map

# ─────────────────────────────────────────
# MAIN PAGE
# ─────────────────────────────────────────
def show():
    st.title("🗺️ Traffic Route Finder")
    st.write("Enter your start and destination to get live traffic info.")

    # ─────────────────────────────────────
    # INPUT SECTION
    # ─────────────────────────────────────
    col1, col2 = st.columns(2)

    with col1:
        origin = st.text_input("📍 Starting Point", placeholder="e.g. Raipur Railway Station")

    with col2:
        destination = st.text_input("🏁 Destination", placeholder="e.g. Raipur Airport")

    search_clicked = st.button("🔍 Search Route")

    # ─────────────────────────────────────
    # SEARCH LOGIC
    # ─────────────────────────────────────
    if search_clicked:

        # Validate inputs
        if not origin or not destination:
            st.error("❌ Please enter both starting point and destination.")
            return

        if origin.strip() == destination.strip():
            st.error("❌ Start and destination cannot be the same.")
            return

        # Show loading spinner while fetching
        with st.spinner("Fetching route and traffic data..."):
            try:
                handler = MapHandler()

                # Step 1 - get coordinates
                start_coords = handler.get_coordinates(origin)
                end_coords   = handler.get_coordinates(destination)

                # Step 2 - get route
                route_result = handler.get_route(start_coords, end_coords)

                # Step 3 - get traffic data
                traffic_data = handler.get_traffic_data(start_coords, end_coords)

                # Step 4 - save to database
                user_id = st.session_state.get("user_id", 1)
                save_route(
                    user_id     = user_id,
                    origin      = origin,
                    destination = destination,
                    distance    = traffic_data["distance"],
                    duration    = traffic_data["traffic_duration"]
                )

                # Store in session for map to use
                st.session_state["route_result"]  = route_result
                st.session_state["traffic_data"]  = traffic_data
                st.session_state["search_done"]   = True

            except Exception as e:
                st.error(f"❌ Error fetching route: {e}")
                return

    # ─────────────────────────────────────
    # RESULTS SECTION
    # ─────────────────────────────────────
    if st.session_state.get("search_done"):
        traffic_data = st.session_state["traffic_data"]
        route_result = st.session_state["route_result"]

        st.divider()

        # Traffic info cards
        col1, col2, col3 = st.columns(3)

        with col1:
            st.metric(
                label = "📏 Distance",
                value = traffic_data["distance"]
            )
        with col2:
            st.metric(
                label = "🕐 Normal Duration",
                value = traffic_data["normal_duration"]
            )
        with col3:
            st.metric(
                label = "🚦 With Traffic",
                value = traffic_data["traffic_duration"]
            )

        # Traffic status badge
        normal  = traffic_data["normal_duration"]
        traffic = traffic_data["traffic_duration"]

        if normal == traffic:
            st.success("🟢 Traffic is clear on this route!")
        else:
            st.warning("🔴 Heavy traffic detected on this route!")

        st.divider()

        # Show map
        st.subheader("🗺️ Route Map")
        render_map(route_result)

        st.divider()

        # Show route history
        st.subheader("📋 Recent Searches")
        user_id = st.session_state.get("user_id", 1)
        history = get_route_history(user_id)

        if history:
            import pandas as pd
            df = pd.DataFrame(history)
            st.dataframe(df, use_container_width=True)
        else:
            st.info("No routes searched yet.")