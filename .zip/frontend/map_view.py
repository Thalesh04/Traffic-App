import folium
import polyline
from streamlit_folium import st_folium

def render_map(route_result):
    # OSRM geometry
    encoded   = route_result["geometry"]
    coords    = polyline.decode(encoded)

    start = coords[0]
    end   = coords[-1]

    map_ = folium.Map(location=start, zoom_start=13)

    folium.PolyLine(
        coords,
        color   = "blue",
        weight  = 5,
        opacity = 0.8
    ).add_to(map_)

    folium.Marker(
        location = start,
        tooltip  = "Start",
        icon     = folium.Icon(color="green", icon="play")
    ).add_to(map_)

    folium.Marker(
        location = end,
        tooltip  = "Destination",
        icon     = folium.Icon(color="red", icon="stop")
    ).add_to(map_)

    st_folium(map_, width=800, height=500)
