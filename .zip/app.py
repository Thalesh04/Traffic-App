import streamlit as st
import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from frontend import home, saved_routes

# Page config
st.set_page_config(
    page_title = "Traffic Route App",
    page_icon  = "🚦",
    layout     = "wide"
)

# Initialize session state
if "search_done" not in st.session_state:
    st.session_state["search_done"] = False
if "user_id" not in st.session_state:
    st.session_state["user_id"] = 1

# ─────────────────────────────────────
# SIDEBAR NAVIGATION
# ─────────────────────────────────────
st.sidebar.title("🚦 Traffic Route App")
st.sidebar.divider()

page = st.sidebar.radio(
    "Navigate",
    ["🏠 Home", "⭐ Saved Routes"]
)

st.sidebar.divider()
st.sidebar.caption("Built with Streamlit + Google Maps")

# ─────────────────────────────────────
# PAGE ROUTING
# ─────────────────────────────────────
if page == "🏠 Home":
    home.show()
elif page == "⭐ Saved Routes":
    saved_routes.show()