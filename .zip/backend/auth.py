import sys
import os
import bcrypt
import sqlite3
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from backend.database import get_connection, create_tables
from typing import Optional

# ─────────────────────────────────────────
# REGISTER
# ─────────────────────────────────────────
def register_user(username: str, password: str) -> bool:
    """
    Register a new user.
    Returns True if successful, False if username already exists.
    """
    conn   = get_connection()
    cursor = conn.cursor()

    # Hash the password before saving
    password_hash = bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt())

    try:
        cursor.execute("""
            INSERT INTO users (username, password_hash)
            VALUES (?, ?)
        """, (username, password_hash))
        conn.commit()
        return True

    except sqlite3.IntegrityError:
        # Username already exists (UNIQUE constraint failed)
        return False

    finally:
        conn.close()


# ─────────────────────────────────────────
# LOGIN
# ─────────────────────────────────────────
def login_user(username: str, password: str) -> Optional[int]:
    """
    Verify login credentials.
    Returns user_id if correct, None if wrong username/password.
    """
    conn   = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, password_hash FROM users
        WHERE username = ?
    """, (username,))

    user = cursor.fetchone()
    conn.close()

    if user is None:
        return None   # username not found

    # Check if entered password matches stored hash
    password_matches = bcrypt.checkpw(
        password.encode("utf-8"),
        user["password_hash"]
    )

    if password_matches:
        return user["id"]   # return user_id on success
    else:
        return None         # wrong password


# ─────────────────────────────────────────
# GET USER
# ─────────────────────────────────────────
def get_user_by_id(user_id: int) -> Optional[dict]:
    """
    Fetch user details by their ID.
    """
    conn   = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT id, username FROM users
        WHERE id = ?
    """, (user_id,))

    user = cursor.fetchone()
    conn.close()

    if user:
        return dict(user)
    return None


# ─────────────────────────────────────────
# TEST
# ─────────────────────────────────────────
if __name__ == "__main__":
    create_tables()

    # Test register
    result = register_user("john", "password123")
    print("✅ Registered:" if result else "❌ Username taken:", "john")

    # Test duplicate register
    result = register_user("john", "password123")
    print("✅ Registered:" if result else "❌ Username taken:", "john")

    # Test login - correct password
    user_id = login_user("john", "password123")
    print("✅ Login success, user_id:", user_id if user_id else "❌ Login failed")

    # Test login - wrong password
    user_id = login_user("john", "wrongpassword")
    print("✅ Login success:" if user_id else "❌ Wrong password - login failed")

    # Test get user
    user = get_user_by_id(1)
    print("👤 User details:", user)