import requests
from typing import Tuple, Dict, Optional
from datetime import datetime
from opencage.geocoder import OpenCageGeocode
import dotenv
import os

dotenv.load_dotenv()

class MapHandler:
    def __init__(self):
        self.geocoder = OpenCageGeocode(os.getenv("OPENCAGE_API_KEY"))

    # ─────────────────────────────────────
    # COORDINATES — uses OpenCage (free, better India coverage)
    # ─────────────────────────────────────
    def get_coordinates(self, address: str) -> Tuple[float, float]:
        # Check if input is already coordinates e.g. "22.7196, 75.8577"
        try:
            parts = address.split(",")
            if len(parts) == 2:
                lat = float(parts[0].strip())
                lon = float(parts[1].strip())
                return (lat, lon)
        except ValueError:
            pass

        # Search with OpenCage
        results = self.geocoder.geocode(address.strip(), countrycode="in")
        if not results:
            raise ValueError(
                f"Could not find '{address}'. "
                f"Try being more specific e.g. '{address}, Indore, Madhya Pradesh'"
            )
        return (results[0]['geometry']['lat'], results[0]['geometry']['lng'])

    # ─────────────────────────────────────
    # ROUTE — uses OSRM (free, no key)
    # ─────────────────────────────────────
    def get_route(self, start: Tuple[float, float],
                  end: Tuple[float, float]) -> Dict:
        url = (
            f"http://router.project-osrm.org/route/v1/driving/"
            f"{start[1]},{start[0]};{end[1]},{end[0]}"
            f"?overview=full&geometries=polyline&steps=true"
        )
        response = requests.get(url)
        data     = response.json()

        if data["code"] != "Ok":
            raise ValueError("Route not found")

        return data["routes"][0]

    # ─────────────────────────────────────
    # TRAFFIC — uses OSRM duration estimate
    # ─────────────────────────────────────
    def get_traffic_data(self, start: Tuple[float, float],
                               end:   Tuple[float, float]) -> Dict:
        url = (
            f"http://router.project-osrm.org/route/v1/driving/"
            f"{start[1]},{start[0]};{end[1]},{end[0]}"
            f"?overview=full"
        )
        response = requests.get(url)
        data     = response.json()

        if data["code"] != "Ok":
            raise ValueError("Route not found")

        route    = data["routes"][0]
        duration = route["duration"]   # in seconds
        distance = route["distance"]   # in meters

        # Convert to readable format
        duration_mins = round(duration / 60)
        distance_km   = round(distance / 1000, 1)

        # Format duration nicely
        if duration_mins >= 60:
            hours = duration_mins // 60
            mins  = duration_mins % 60
            duration_text = f"{hours} hr {mins} mins"
        else:
            duration_text = f"{duration_mins} mins"

        return {
            "normal_duration":  duration_text,
            "traffic_duration": duration_text,
            "distance":         f"{distance_km} km"
        }
