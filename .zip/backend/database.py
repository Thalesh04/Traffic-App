import sqlite3
import os
from datetime import datetime
from typing import List, Dict, Optional

DB_PATH = "data/traffic_routes.db"

def get_connection():
    os.makedirs("data", exist_ok=True)   # ← add this line
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn
# ─────────────────────────────────────────
# CREATE TABLES
# ─────────────────────────────────────────
def create_tables():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id            INTEGER PRIMARY KEY AUTOINCREMENT,
            username      TEXT    UNIQUE NOT NULL,
            password_hash TEXT    NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS routes (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            origin      TEXT    NOT NULL,
            destination TEXT    NOT NULL,
            distance    TEXT,
            duration    TEXT,
            timestamp   TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS frequent_routes (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id     INTEGER NOT NULL,
            origin      TEXT    NOT NULL,
            destination TEXT    NOT NULL,
            trip_count  INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    """)

    conn.commit()
    conn.close()

# ─────────────────────────────────────────
# SAVE ROUTE
# ─────────────────────────────────────────
def save_route(user_id: int, origin: str,
               destination: str, distance: str, duration: str):
    conn   = get_connection()
    cursor = conn.cursor()

    # Save to routes history
    cursor.execute("""
        INSERT INTO routes (user_id, origin, destination, distance, duration, timestamp)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (user_id, origin, destination, distance, duration,
          datetime.now().strftime("%Y-%m-%d %H:%M:%S")))

    # Check if this route already exists in frequent_routes
    cursor.execute("""
        SELECT id FROM frequent_routes
        WHERE user_id=? AND origin=? AND destination=?
    """, (user_id, origin, destination))

    existing = cursor.fetchone()

    if existing:
        # Route exists → increment count
        cursor.execute("""
            UPDATE frequent_routes SET trip_count = trip_count + 1
            WHERE id = ?
        """, (existing['id'],))
    else:
        # New route → insert it
        cursor.execute("""
            INSERT INTO frequent_routes (user_id, origin, destination, trip_count)
            VALUES (?, ?, ?, 1)
        """, (user_id, origin, destination))

    conn.commit()
    conn.close()

# ─────────────────────────────────────────
# FETCH ROUTES
# ─────────────────────────────────────────
def get_route_history(user_id: int) -> List[Dict]:
    conn   = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT origin, destination, distance, duration, timestamp
        FROM routes
        WHERE user_id = ?
        ORDER BY timestamp DESC
    """, (user_id,))

    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]   # convert Row objects to plain dicts


def get_frequent_routes(user_id: int) -> List[Dict]:
    conn   = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        SELECT origin, destination, trip_count
        FROM frequent_routes
        WHERE user_id = ?
        ORDER BY trip_count DESC
    """, (user_id,))

    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

if __name__ == "__main__":

    # Step 1 - create tables
    create_tables()
    print("✅ Tables created")

    # Step 2 - save a test route
    save_route(
        user_id     = 1,
        origin      = "Raipur Railway Station",
        destination = "Raipur Airport",
        distance    = "12 km",
        duration    = "25 mins"
    )
    print("✅ Route saved")

    # Step 3 - fetch route history
    history = get_route_history(user_id=1)
    print("\n📋 Route History:")
    for route in history:
        print(route)

    # Step 4 - fetch frequent routes
    frequent = get_frequent_routes(user_id=1)
    print("\n⭐ Frequent Routes:")
    for route in frequent:
        print(route)